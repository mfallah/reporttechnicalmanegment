/**
 * API Route: POST /api/generate-report
 *
 * Accepts a multipart/form-data upload with:
 *   - file: the xlsx/xlsm file (required)
 *   - threshold: optional override for the gap threshold (Excel time fraction)
 *
 * Supports both input formats:
 *   - Raw-data-only daily files (single sheet with A-F columns)
 *   - Original multi-sheet template files (دیتای کارکرد + Sheet1 + تعیین میانه)
 *
 * Returns a JSON response containing:
 *   {
 *     ok: true,
 *     meta: { rowCount, rawCount, threshold, thresholdFmt, detectedFormat,
 *            unknownAreas, warnings },
 *     activityHeaders: string[],
 *     preview: ReportRow[],   // first 50 rows for the preview table
 *     fileName: string,
 *     fileBase64: string      // base64-encoded xlsx (decoded client-side)
 *   }
 *
 * On error returns: { ok: false, error: string }
 *
 * The file is returned as base64 inside the JSON body (not as a binary
 * download) to avoid HTTP header size limits when the preview is large.
 */
import { NextRequest, NextResponse } from "next/server";
import {
  processExcelFile,
  buildReportWorkbook,
  type ProcessResult,
} from "@/lib/excelProcessor";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_FILE_BYTES = 25 * 1024 * 1024; // 25 MB

export async function POST(req: NextRequest) {
  try {
    const form = await req.formData();
    const file = form.get("file");
    const thresholdStr = form.get("threshold");

    if (!(file instanceof File)) {
      return NextResponse.json(
        { ok: false, error: "فایلی آپلود نشده است. لطفاً فایل اکسل را انتخاب کنید." },
        { status: 400 }
      );
    }
    if (file.size === 0) {
      return NextResponse.json(
        { ok: false, error: "فایل آپلود شده خالی است." },
        { status: 400 }
      );
    }
    if (file.size > MAX_FILE_BYTES) {
      return NextResponse.json(
        { ok: false, error: "حجم فایل بیش از حد مجاز (۲۵ مگابایت) است." },
        { status: 400 }
      );
    }

    const lower = file.name.toLowerCase();
    if (!(lower.endsWith(".xlsx") || lower.endsWith(".xlsm"))) {
      return NextResponse.json(
        {
          ok: false,
          error:
            "فقط فایل‌های اکسل با پسوند .xlsx یا .xlsm پذیرفته می‌شوند.",
        },
        { status: 400 }
      );
    }

    const buf = await file.arrayBuffer();

    let thresholdOverride: number | null = null;
    if (typeof thresholdStr === "string" && thresholdStr.trim() !== "") {
      const n = Number(thresholdStr);
      if (!isNaN(n)) {
        thresholdOverride = n;
      }
    }

    let result: ProcessResult;
    try {
      result = await processExcelFile(buf, { thresholdOverride });
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      console.error("[generate-report] processing error:", e);
      return NextResponse.json(
        { ok: false, error: `خطا در پردازش فایل: ${msg}` },
        { status: 500 }
      );
    }

    if (result.reportRows.length === 0) {
      return NextResponse.json(
        {
          ok: false,
          error:
            "هیچ ردیف گزارشی تولید نشد. لطفاً مطمئن شوید فایل شامل دیتای خام با ستون‌های تاریخ و کد منطقه است.",
        },
        { status: 400 }
      );
    }

    const outBuf = await buildReportWorkbook(result);

    // Build preview — first 50 rows, with minimal field set
    const preview = result.reportRows.slice(0, 50).map((r) => ({
      date: r.date,
      areaName: r.areaName,
      areaCode: r.areaCode,
      supporter: r.supporter,
      counts: [
        r.counts["col5"] ?? 0,
        r.counts["col6"] ?? 0,
        r.counts["col7"] ?? 0,
        r.counts["col8"] ?? 0,
        r.counts["col9"] ?? 0,
      ],
      morningStart: r.morningStart,
      morningEnd: r.morningEnd,
      afternoonStart: r.afternoonStart,
      afternoonEnd: r.afternoonEnd,
      usefulHours: r.usefulHours,
      gapCount: r.gapCount,
    }));

    // Convert the xlsx buffer to base64 for embedding in the JSON response.
    // We use chunked conversion to handle large buffers efficiently.
    const base64 = bufferToBase64(outBuf);

    const dateStr = new Date().toISOString().slice(0, 10);
    const fileName = `گزارش-کارکرد-${dateStr}.xlsx`;

    return NextResponse.json(
      {
        ok: true,
        meta: {
          rowCount: result.reportRows.length,
          rawCount: result.rawDataCount,
          threshold: result.threshold,
          thresholdFmt: result.thresholdFormatted,
          detectedFormat: result.detectedFormat,
          unknownAreas: result.unknownAreaCodes,
          warnings: result.warnings,
        },
        activityHeaders: result.activityHeaders,
        preview,
        fileName,
        fileBase64: base64,
      },
      { status: 200 }
    );
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error("[generate-report] unexpected error:", err);
    return NextResponse.json(
      { ok: false, error: `خطای پیش‌بینی‌نشده: ${msg}` },
      { status: 500 }
    );
  }
}

/**
 * Convert an ArrayBuffer or Uint8Array to a base64 string using chunked
 * conversion to avoid the call-stack-size limit for large buffers.
 */
function bufferToBase64(buf: ArrayBuffer | Uint8Array): string {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  const CHUNK = 0x8000; // 32 KB chunks
  let result = "";
  for (let i = 0; i < bytes.length; i += CHUNK) {
    const slice = bytes.subarray(i, Math.min(i + CHUNK, bytes.length));
    result += String.fromCharCode.apply(null, slice as unknown as number[]);
  }
  return btoa(result);
}
