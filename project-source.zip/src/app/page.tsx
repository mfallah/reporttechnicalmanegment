"use client";

import { useState, useCallback, useRef, useMemo } from "react";
import {
  Upload,
  FileSpreadsheet,
  Download,
  Loader2,
  AlertCircle,
  CheckCircle2,
  Clock,
  Settings2,
  Table2,
  Sparkles,
  ShieldCheck,
  Zap,
  Info,
  FileText,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Toaster } from "@/components/ui/toaster";
import { useToast } from "@/hooks/use-toast";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface PreviewRow {
  date: string;
  areaName: string;
  areaCode: string;
  supporter: string;
  counts: number[];
  morningStart: number | null;
  morningEnd: number | null;
  afternoonStart: number | null;
  afternoonEnd: number | null;
  usefulHours: number | null;
  gapCount: number;
}

interface ReportMeta {
  rowCount: number;
  rawCount: number;
  threshold: number;
  thresholdFmt: string;
  activityHeaders: string[];
  preview: PreviewRow[];
  detectedFormat: "raw-only" | "template";
  unknownAreas: string[];
  warnings: string[];
  fileName: string;
  fileSize: number;
}

function fmtExcelTime(t: number | null): string {
  if (t === null || t === undefined || isNaN(t)) return "—";
  const frac = t - Math.floor(t);
  const totalSeconds = Math.round(frac * 86400);
  const h = Math.floor(totalSeconds / 3600);
  const mm = Math.floor((totalSeconds % 3600) / 60);
  const ss = totalSeconds % 60;
  return `${String(h).padStart(2, "0")}:${String(mm).padStart(2, "0")}:${String(ss).padStart(2, "0")}`;
}

function fmtExcelDuration(t: number | null): string {
  if (t === null || t === undefined || isNaN(t) || t === 0) return "—";
  const totalSeconds = Math.round(Math.abs(t) * 86400);
  const h = Math.floor(totalSeconds / 3600);
  const mm = Math.floor((totalSeconds % 3600) / 60);
  const ss = totalSeconds % 60;
  return `${h}:${String(mm).padStart(2, "0")}:${String(ss).padStart(2, "0")}`;
}

function fmtFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export default function Home() {
  const [file, setFile] = useState<File | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [meta, setMeta] = useState<ReportMeta | null>(null);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [thresholdInput, setThresholdInput] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const reset = useCallback(() => {
    if (downloadUrl) URL.revokeObjectURL(downloadUrl);
    setDownloadUrl(null);
    setMeta(null);
    setError(null);
  }, [downloadUrl]);

  const onPickFile = useCallback(
    (f: File | null) => {
      reset();
      const lower = f?.name.toLowerCase() ?? "";
      if (f && !(lower.endsWith(".xlsx") || lower.endsWith(".xlsm"))) {
        setError("فقط فایل‌های با پسوند .xlsx یا .xlsm پذیرفته می‌شوند.");
        setFile(null);
        return;
      }
      setFile(f);
    },
    [reset]
  );

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragOver(false);
      const f = e.dataTransfer.files?.[0] ?? null;
      onPickFile(f);
    },
    [onPickFile]
  );

  const onGenerate = useCallback(async () => {
    if (!file) {
      setError("لطفاً ابتدا فایل اکسل را انتخاب کنید.");
      return;
    }
    setLoading(true);
    setError(null);
    if (downloadUrl) {
      URL.revokeObjectURL(downloadUrl);
      setDownloadUrl(null);
    }
    setMeta(null);

    try {
      const fd = new FormData();
      fd.append("file", file);
      if (thresholdInput.trim()) {
        fd.append("threshold", thresholdInput.trim());
      }

      const res = await fetch("/api/generate-report", {
        method: "POST",
        body: fd,
      });

      // Always try to parse the response as JSON. The server now returns a
      // single JSON body (with the file embedded as base64) — no binary
      // download, no large HTTP headers. This avoids the gateway's 8192-byte
      // header limit that was causing 502 errors on multi-day data.
      let data: {
        ok?: boolean;
        error?: string;
        meta?: {
          rowCount: number;
          rawCount: number;
          threshold: number;
          thresholdFmt: string;
          detectedFormat: "raw-only" | "template";
          unknownAreas: string[];
          warnings: string[];
        };
        activityHeaders?: string[];
        preview?: PreviewRow[];
        fileName?: string;
        fileBase64?: string;
      };

      try {
        data = await res.json();
      } catch {
        // Not JSON — extract text for the error message
        const text = await res.text().catch(() => "");
        throw new Error(
          text
            ? `پاسخ سرور قابل خواندن نیست (کد HTTP ${res.status}): ${text.slice(0, 500)}`
            : `پاسخ سرور قابل خواندن نیست (کد HTTP ${res.status}).`
        );
      }

      if (!res.ok || !data.ok) {
        throw new Error(
          data.error || `خطا در تولید گزارش (کد HTTP ${res.status}).`
        );
      }

      if (!data.fileBase64) {
        throw new Error("فایل خروجی از سرور دریافت نشد.");
      }

      // Decode base64 -> Uint8Array -> Blob
      const binaryString = atob(data.fileBase64);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      const url = URL.createObjectURL(blob);
      setDownloadUrl(url);

      const meta = data.meta!;
      setMeta({
        rowCount: meta.rowCount,
        rawCount: meta.rawCount,
        threshold: meta.threshold,
        thresholdFmt: meta.thresholdFmt,
        activityHeaders: data.activityHeaders ?? [],
        preview: data.preview ?? [],
        detectedFormat: meta.detectedFormat,
        unknownAreas: meta.unknownAreas ?? [],
        warnings: meta.warnings ?? [],
        fileName: file.name,
        fileSize: file.size,
      });
      toast({
        title: "گزارش با موفقیت تولید شد",
        description: `${meta.rowCount} ردیف گزارش بر اساس ${meta.rawCount} رکورد دیتای خام.`,
      });
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      setError(msg);
      toast({ title: "خطا", description: msg, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [file, thresholdInput, downloadUrl, toast]);

  const canGenerate = !!file && !loading;

  const thresholdHint = useMemo(() => {
    if (meta) {
      return `مقدار فعلی: ${meta.thresholdFmt} (Excel: ${meta.threshold.toFixed(6)}) — این مقدار هم برای تفکیک صبح/عصر و هم برای شمارش گپ‌ها استفاده می‌شود.`;
    }
    return "مقدار پیش‌فرض ۱۴:۰۰:۳۳ است (یا از شیت «تعیین میانه» خوانده می‌شود). این مقدار هم برای تفکیک صبح/عصر و هم برای شمارش گپ‌ها استفاده می‌شود.";
  }, [meta]);

  return (
    <TooltipProvider delayDuration={200}>
      <div
        dir="rtl"
        className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 text-slate-900"
      >
        <Toaster />
        {/* Header */}
        <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-10">
          <div className="mx-auto max-w-6xl px-4 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center shadow-sm">
                <FileSpreadsheet className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-slate-900 leading-tight">
                  گزارش کارکرد هوشمند
                </h1>
                <p className="text-xs text-slate-500">
                  ابزار تولید سریع گزارش بدون فرمول
                </p>
              </div>
            </div>
            <Badge
              variant="outline"
              className="bg-emerald-50 text-emerald-700 border-emerald-200"
            >
              <Sparkles className="w-3 h-3 ml-1" />
              نسخه ۱.۱
            </Badge>
          </div>
        </header>

        <main className="mx-auto max-w-6xl px-4 py-8 pb-24">
          {/* Intro section */}
          <section className="mb-8">
            <div className="text-center mb-6">
              <h2 className="text-3xl font-bold text-slate-900 mb-3">
                فایل اکسل دیتای خام را آپلود کنید،
                <span className="text-emerald-600"> گزارش آماده</span> را
                دریافت کنید
              </h2>
              <p className="text-slate-600 max-w-2xl mx-auto leading-relaxed">
                این ابزار تمام محاسبات (شمارش فعالیت‌ها، تعیین زمان شروع و
                پایان صبح و بعدازظهر، محاسبه کارکرد مفید و تعداد گپ‌های زمانی)
                را به جای اکسل انجام می‌دهد و یک فایل گزارش نهایی{" "}
                <strong>بدون فرمول</strong> و سبک به شما تحویل می‌دهد.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <FeatureCard
                icon={<Zap className="w-5 h-5" />}
                title="سرعت بالا"
                desc="محاسبات در کسری از ثانیه انجام می‌شود، بدون هنگ کردن سیستم."
              />
              <FeatureCard
                icon={<ShieldCheck className="w-5 h-5" />}
                title="بدون فرمول"
                desc="گزارش نهایی فقط شامل مقادیر محاسبه‌شده است؛ سبک و بدون وابستگی."
              />
              <FeatureCard
                icon={<Table2 className="w-5 h-5" />}
                title="ساختار یکسان"
                desc="دقیقاً همان ستون‌ها و چیدمان فایل اصلی، با قابلیت پیش‌نمایش."
              />
            </div>
          </section>

          {/* Format info banner */}
          <section className="mb-6">
            <Alert className="border-sky-200 bg-sky-50">
              <Info className="w-4 h-4 text-sky-600" />
              <AlertTitle className="text-sky-900">دو نوع فایل ورودی پشتیبانی می‌شود</AlertTitle>
              <AlertDescription className="text-sky-800">
                <div className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                  <div className="flex items-start gap-2">
                    <FileText className="w-4 h-4 mt-0.5 flex-shrink-0 text-sky-600" />
                    <div>
                      <strong>دیتای خام روزانه:</strong> یک شیت با ۶ ستون (عنوان دوره،
                      شماره ترمینال، کد منطقه، نوع پشتیبانی، تاریخ، زمان). هر روز فقط
                      دیتای خام را آپلود کنید.
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <FileSpreadsheet className="w-4 h-4 mt-0.5 flex-shrink-0 text-sky-600" />
                    <div>
                      <strong>قالب اصلی چندشیت:</strong> فایل کامل با شیت‌های «دیتای
                      کارکرد»، «Sheet1» و «تعیین میانه». برای سازگاری با نسخه قبلی.
                    </div>
                  </div>
                </div>
              </AlertDescription>
            </Alert>
          </section>

          {/* Upload + actions */}
          <section className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <div className="lg:col-span-2">
              <Card className="p-6 shadow-sm border-slate-200">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-slate-900 flex items-center gap-2">
                    <Upload className="w-4 h-4 text-emerald-600" />
                    فایل ورودی
                  </h3>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button
                        onClick={() => setShowAdvanced((s) => !s)}
                        className="text-xs text-slate-500 hover:text-slate-700 flex items-center gap-1"
                      >
                        <Settings2 className="w-3.5 h-3.5" />
                        تنظیمات پیشرفته
                      </button>
                    </TooltipTrigger>
                    <TooltipContent>
                      تنظیمات آستانه گپ زمانی
                    </TooltipContent>
                  </Tooltip>
                </div>

                {showAdvanced && (
                  <div className="mb-4 p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <Label
                      htmlFor="threshold"
                      className="text-sm font-medium text-slate-700 mb-2 block"
                    >
                      آستانه گپ زمانی (Excel time fraction)
                    </Label>
                    <Input
                      id="threshold"
                      placeholder="مثلاً ۰.۵۸۳۷ (خالی = استفاده از پیش‌فرض ۱۴:۰۰:۳۳)"
                      value={thresholdInput}
                      onChange={(e) => setThresholdInput(e.target.value)}
                      dir="ltr"
                      className="text-left font-mono"
                    />
                    <p className="text-xs text-slate-500 mt-2">{thresholdHint}</p>
                  </div>
                )}

                {/* Drop zone */}
                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setDragOver(true);
                  }}
                  onDragLeave={() => setDragOver(false)}
                  onDrop={onDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`cursor-pointer border-2 border-dashed rounded-xl p-8 text-center transition-colors ${
                    dragOver
                      ? "border-emerald-500 bg-emerald-50"
                      : "border-slate-300 bg-slate-50 hover:bg-slate-100"
                  }`}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".xlsx,.xlsm"
                    className="hidden"
                    onChange={(e) => onPickFile(e.target.files?.[0] ?? null)}
                  />
                  {file ? (
                    <div className="flex items-center justify-center gap-3">
                      <div className="w-12 h-12 rounded-lg bg-emerald-100 flex items-center justify-center">
                        <FileSpreadsheet className="w-6 h-6 text-emerald-600" />
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-slate-900">
                          {file.name}
                        </p>
                        <p className="text-xs text-slate-500">
                          {fmtFileSize(file.size)}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <Upload className="w-10 h-10 text-slate-400 mx-auto mb-3" />
                      <p className="font-medium text-slate-700 mb-1">
                        فایل اکسل را اینجا بکشید یا کلیک کنید
                      </p>
                      <p className="text-xs text-slate-500">
                        فرمت‌های پشتیبانی‌شده: .xlsx, .xlsm
                      </p>
                    </div>
                  )}
                </div>

                <div className="mt-5 flex flex-wrap items-center gap-3">
                  <Button
                    onClick={onGenerate}
                    disabled={!canGenerate}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm"
                    size="lg"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                        در حال تولید گزارش...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 ml-2" />
                        تولید گزارش
                      </>
                    )}
                  </Button>
                  {file && (
                    <Button
                      variant="ghost"
                      onClick={() => onPickFile(null)}
                      disabled={loading}
                    >
                      پاک کردن
                    </Button>
                  )}
                </div>

                {error && (
                  <Alert variant="destructive" className="mt-4">
                    <AlertCircle className="w-4 h-4" />
                    <AlertTitle>خطا</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}
              </Card>
            </div>

            {/* Side: download panel */}
            <div className="lg:col-span-1">
              <Card className="p-6 shadow-sm border-slate-200 h-full">
                <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
                  <Download className="w-4 h-4 text-emerald-600" />
                  دانلود گزارش
                </h3>
                {downloadUrl ? (
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 p-3 bg-emerald-50 rounded-lg border border-emerald-200">
                      <CheckCircle2 className="w-8 h-8 text-emerald-600 flex-shrink-0" />
                      <div>
                        <p className="font-semibold text-emerald-900">
                          آماده دانلود
                        </p>
                        <p className="text-xs text-emerald-700">
                          فایل گزارش نهایی بدون فرمول
                        </p>
                      </div>
                    </div>
                    <a href={downloadUrl} download="گزارش-کارکرد.xlsx">
                      <Button
                        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                        size="lg"
                      >
                        <Download className="w-4 h-4 ml-2" />
                        دانلود فایل اکسل
                      </Button>
                    </a>
                    {meta && (
                      <div className="text-xs text-slate-600 space-y-1 pt-2 border-t border-slate-200">
                        <div className="flex justify-between">
                          <span>قالب تشخیص‌داده‌شده:</span>
                          <span className="font-mono font-semibold">
                            {meta.detectedFormat === "raw-only"
                              ? "دیتای خام"
                              : "قالب اصلی"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>ردیف‌های گزارش:</span>
                          <span className="font-mono font-semibold">
                            {meta.rowCount}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>رکوردهای دیتای خام:</span>
                          <span className="font-mono font-semibold">
                            {meta.rawCount}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>آستانه گپ:</span>
                          <span className="font-mono font-semibold">
                            {meta.thresholdFmt}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8 text-slate-400">
                    <Download className="w-12 h-12 mx-auto mb-3 opacity-40" />
                    <p className="text-sm">
                      پس از آپلود فایل و کلیک روی «تولید گزارش»، لینک دانلود
                      در اینجا نمایش داده می‌شود.
                    </p>
                  </div>
                )}
              </Card>
            </div>
          </section>

          {/* Warnings */}
          {meta && meta.warnings.length > 0 && (
            <section className="mb-6">
              <Alert className="border-amber-200 bg-amber-50">
                <AlertCircle className="w-4 h-4 text-amber-600" />
                <AlertTitle className="text-amber-900">هشدار</AlertTitle>
                <AlertDescription className="text-amber-800">
                  <ul className="list-disc pr-5 mt-1 space-y-1">
                    {meta.warnings.map((w, i) => (
                      <li key={i}>{w}</li>
                    ))}
                  </ul>
                </AlertDescription>
              </Alert>
            </section>
          )}

          {/* Unknown area codes */}
          {meta && meta.unknownAreas.length > 0 && (
            <section className="mb-6">
              <Alert className="border-orange-200 bg-orange-50">
                <AlertCircle className="w-4 h-4 text-orange-600" />
                <AlertTitle className="text-orange-900">
                  کد منطقه‌های ناشناخته
                </AlertTitle>
                <AlertDescription className="text-orange-800">
                  <p className="mb-2">
                    کد منطقه‌های زیر در فایل ورودی یافت شدند اما در نقشه پشتیبان
                    تعریف نشده‌اند. لطفاً نام ناحیه و پشتیبان را در فایل خروجی
                    به‌صورت دستی تکمیل کنید:
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {meta.unknownAreas.map((code) => (
                      <Badge
                        key={code}
                        variant="outline"
                        className="bg-orange-100 text-orange-800 border-orange-300 font-mono"
                      >
                        {code}
                      </Badge>
                    ))}
                  </div>
                </AlertDescription>
              </Alert>
            </section>
          )}

          {/* Preview table */}
          {meta && meta.preview.length > 0 && (
            <section>
              <Card className="p-6 shadow-sm border-slate-200">
                <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
                  <h3 className="font-bold text-slate-900 flex items-center gap-2">
                    <Table2 className="w-4 h-4 text-emerald-600" />
                    پیش‌نمایش گزارش
                    <Badge variant="secondary" className="text-xs">
                      {meta.preview.length} از {meta.rowCount} ردیف
                    </Badge>
                  </h3>
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <Clock className="w-3.5 h-3.5" />
                    {new Date().toLocaleString("fa-IR")}
                  </div>
                </div>

                <div className="overflow-x-auto rounded-lg border border-slate-200">
                  <table className="w-full text-xs text-center">
                    <thead className="bg-slate-100 text-slate-700">
                      <tr>
                        <th className="px-2 py-2 font-semibold whitespace-nowrap">تاریخ</th>
                        <th className="px-2 py-2 font-semibold whitespace-nowrap">ناحیه</th>
                        <th className="px-2 py-2 font-semibold whitespace-nowrap">کد منطقه</th>
                        <th className="px-2 py-2 font-semibold whitespace-nowrap">پشتیبان</th>
                        {meta.activityHeaders.slice(0, 5).map((h, i) => (
                          <th
                            key={i}
                            className="px-2 py-2 font-semibold whitespace-nowrap"
                          >
                            {h}
                          </th>
                        ))}
                        <th className="px-2 py-2 font-semibold whitespace-nowrap">شروع صبح</th>
                        <th className="px-2 py-2 font-semibold whitespace-nowrap">پایان صبح</th>
                        <th className="px-2 py-2 font-semibold whitespace-nowrap">شروع ب.ظهر</th>
                        <th className="px-2 py-2 font-semibold whitespace-nowrap">پایان ب.ظهر</th>
                        <th className="px-2 py-2 font-semibold whitespace-nowrap bg-emerald-50">کارکرد مفید</th>
                        <th className="px-2 py-2 font-semibold whitespace-nowrap">گپ</th>
                      </tr>
                    </thead>
                    <tbody>
                      {meta.preview.map((r, i) => (
                        <tr
                          key={i}
                          className={i % 2 === 1 ? "bg-slate-50" : "bg-white"}
                        >
                          <td className="px-2 py-2 font-mono whitespace-nowrap">{r.date}</td>
                          <td className="px-2 py-2 whitespace-nowrap">{r.areaName || "—"}</td>
                          <td className="px-2 py-2 font-mono whitespace-nowrap">{r.areaCode}</td>
                          <td className="px-2 py-2 whitespace-nowrap">{r.supporter || "—"}</td>
                          {(r.counts || []).slice(0, 5).map((c, ci) => (
                            <td
                              key={ci}
                              className={`px-2 py-2 font-mono ${c > 0 ? "text-slate-900" : "text-slate-300"}`}
                            >
                              {c}
                            </td>
                          ))}
                          <td className="px-2 py-2 font-mono whitespace-nowrap text-slate-600">
                            {fmtExcelTime(r.morningStart)}
                          </td>
                          <td className="px-2 py-2 font-mono whitespace-nowrap text-slate-600">
                            {fmtExcelTime(r.morningEnd)}
                          </td>
                          <td className="px-2 py-2 font-mono whitespace-nowrap text-slate-600">
                            {fmtExcelTime(r.afternoonStart)}
                          </td>
                          <td className="px-2 py-2 font-mono whitespace-nowrap text-slate-600">
                            {fmtExcelTime(r.afternoonEnd)}
                          </td>
                          <td className="px-2 py-2 font-mono whitespace-nowrap bg-emerald-50 text-emerald-700 font-semibold">
                            {fmtExcelDuration(r.usefulHours)}
                          </td>
                          <td className="px-2 py-2 font-mono whitespace-nowrap">
                            {r.gapCount > 0 ? (
                              <Badge
                                variant="outline"
                                className="bg-amber-50 text-amber-700 border-amber-200"
                              >
                                {r.gapCount}
                              </Badge>
                            ) : (
                              <span className="text-slate-300">0</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {meta.rowCount > meta.preview.length && (
                  <p className="text-xs text-slate-500 mt-3 text-center">
                    برای مشاهده تمام {meta.rowCount} ردیف، فایل اکسل را دانلود
                    کنید.
                  </p>
                )}
              </Card>
            </section>
          )}

          {/* How it works */}
          <section className="mt-12">
            <h3 className="text-xl font-bold text-slate-900 mb-4 text-center">
              این ابزار چگونه کار می‌کند؟
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <StepCard
                step={1}
                title="آپلود فایل"
                desc="فایل روزانه خود را آپلود کنید. فقط کافی است شامل ستون‌های تاریخ و کد منطقه باشد."
              />
              <StepCard
                step={2}
                title="تشخیص خودکار قالب"
                desc="ابزار قالب فایل را تشخیص می‌دهد: دیتای خام روزانه یا قالب اصلی چندشیت."
              />
              <StepCard
                step={3}
                title="محاسبه خودکار"
                desc="شمارش فعالیت‌ها، زمان شروع/پایان، کارکرد مفید و گپ‌های زمانی — بدون فرمول."
              />
              <StepCard
                step={4}
                title="دانلود گزارش"
                desc="فایل نهایی اکسل را با مقادیر محاسبه‌شده دانلود کنید."
              />
            </div>
          </section>
        </main>

        <footer className="border-t border-slate-200 bg-white mt-auto">
          <div className="mx-auto max-w-6xl px-4 py-6 text-center text-xs text-slate-500">
            <p>
              تمام پردازش‌ها روی سرور انجام می‌شود؛ فایل شما پس از تولید گزارش
              نگه‌داری نمی‌شود.
            </p>
          </div>
        </footer>
      </div>
    </TooltipProvider>
  );
}

function FeatureCard({
  icon,
  title,
  desc,
}: {
  icon: React.ReactNode;
  title: string;
  desc: string;
}) {
  return (
    <Card className="p-5 border border-emerald-200 bg-emerald-50 shadow-sm">
      <div className="w-10 h-10 rounded-lg bg-white flex items-center justify-center mb-3 shadow-sm">
        {icon}
      </div>
      <h4 className="font-bold text-slate-900 mb-1">{title}</h4>
      <p className="text-sm text-slate-600 leading-relaxed">{desc}</p>
    </Card>
  );
}

function StepCard({
  step,
  title,
  desc,
}: {
  step: number;
  title: string;
  desc: string;
}) {
  return (
    <Card className="p-5 border-slate-200 shadow-sm">
      <div className="flex items-center gap-3 mb-3">
        <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-sm">
          {step}
        </div>
        <h4 className="font-bold text-slate-900">{title}</h4>
      </div>
      <p className="text-sm text-slate-600 leading-relaxed">{desc}</p>
    </Card>
  );
}
