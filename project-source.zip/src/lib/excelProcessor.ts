/**
 * Excel Processor - Core logic to replicate the report formulas
 *
 * SUPPORTS TWO INPUT FORMATS:
 *
 * 1. Raw-data-only file (the daily upload format, e.g. Book4.xlsx):
 *    - Single sheet with columns A-F:
 *      A: عنوان دوره (activity type: نصب, EM, pm/1404-4, EM ویژه, بازاریابی)
 *      B: شماره ترمینال (terminal number)
 *      C: کد منطقه استحفاظی (area code)
 *      D: نوع پشتیبانی ثبت شده (support type, ignored)
 *      E: تاریخ پشتیبانی (Persian date, e.g. "1405/06/03")
 *      F: زمان پشتیبانی (Excel time fraction or "HH:MM:SS" string)
 *    - The processor discovers all unique (date, areaCode) combos and
 *      generates report rows dynamically, looking up (areaName, supporter)
 *      from the built-in AREA_MAP.
 *
 * 2. Multi-sheet file (original template format, e.g. "گزارش کارکرد هوشمند.xlsm"):
 *    - Sheet "دیتای کارکرد": raw data (same columns as above)
 *    - Sheet "Sheet1": report template with rows defining date/area/supporter
 *    - Sheet "تعیین میانه": B2 = gap-counting threshold (Excel time fraction)
 *
 * COMPUTED COLUMNS (matching original Sheet1 layout):
 *   A: تاریخ (date)              B: نام ناحیه (area name)
 *   C: کد منطقه (area code)      D: پشتیبان (supporter)
 *   E..I: counts per activity type (5 columns, auto-detected from data)
 *   J: کد ملی صاحب حساب بازاریابی (manual, left empty)
 *   K: ساعت شروع بکار صبح (min morning time, < 13:00)
 *   L: ساعت پایان بکار صبح (max morning time, < 13:00)
 *   M: ساعت شروع بکار بعداز ظهر (min afternoon time, >= 13:00)
 *   N: ساعت پایان بکار بعداز ظهر (max afternoon time, >= 13:00)
 *   O: ساعت کار کرد مفید = (L-K) + (N-M)
 *   P: توضیحات (notes, empty)
 *   Q: تعداد کار با گپ (CountTimeGaps custom function)
 */

import ExcelJS from "exceljs";

// ---- Constants ----

/**
 * Default median threshold (Excel time fraction) = 14:00:33
 *
 * This single threshold serves TWO purposes (both matching the original
 * Excel template's "تعیین میانه" sheet B2 value):
 *   1. Morning/afternoon split: times < threshold are MORNING, times >=
 *      threshold are AFTERNOON. (The original Excel formulas used
 *      TIME(13,0,0), but the user confirmed this was wrong — the median
 *      should be the split point.)
 *   2. Gap counting: consecutive records whose time delta exceeds this
 *      threshold count as a "gap" (replicates the VBA CountTimeGaps
 *      function which reads this value from تعیین میانه!$B$2).
 */
export const DEFAULT_THRESHOLD = 0.5837152777777778;

/**
 * Built-in map of area code → (area name, supporter).
 * Extracted from the original "گزارش کارکرد هوشمند.xlsm" template file.
 * Users can extend this via the UI settings (stored in localStorage).
 */
export interface AreaInfo {
  areaName: string;
  supporter: string;
}

export const DEFAULT_AREA_MAP: Record<string, AreaInfo> = {
  "2741": { areaName: "فلاح", supporter: "ذوالفقاری" },
  "2742": { areaName: "فلاح", supporter: "عزیزی" },
  "2743": { areaName: "فلاح", supporter: "کولیوند" },
  "2744": { areaName: "فلاح", supporter: "مقدم" },
  "2745": { areaName: "فلاح", supporter: "علیزاده" },
  "2746": { areaName: "فلاح", supporter: "احمدی" },
};

/**
 * Activity type normalization. The same logical activity may appear under
 * different names in different daily files (e.g. "pm" vs "1404-4"). We
 * normalize them to a canonical label before counting.
 *
 * The original template's report headers were:
 *   E2="1404-4", F2="EM", G2="نصب", H2="EM ویژه", I2="بازاریابی"
 *
 * In the new daily files, "pm" appears instead of "1404-4" — they are the
 * same concept (periodic maintenance visit). We map both to "1404-4" so the
 * report column stays stable.
 */
const ACTIVITY_ALIASES: Record<string, string> = {
  pm: "1404-4",
  "1404-4": "1404-4",
  em: "EM",
  نصب: "نصب",
  "em ویژه": "EM ویژه",
  "بازاریابی": "بازاریابی",
};

/** Canonical activity headers in display order (matches original template). */
const DEFAULT_ACTIVITY_HEADERS = [
  "1404-4",
  "EM",
  "نصب",
  "EM ویژه",
  "بازاریابی",
];

// ---- Time helpers ----

/**
 * Convert a time value (string "HH:MM:SS" or Excel time fraction or Date) to
 * an Excel time fraction (0..1).
 */
export function toExcelTime(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value === "number") {
    if (value > 1) return value - Math.floor(value);
    return value;
  }
  if (value instanceof Date) {
    const totalSeconds =
      value.getHours() * 3600 +
      value.getMinutes() * 60 +
      value.getSeconds();
    return totalSeconds / 86400;
  }
  if (typeof value === "string") {
    const s = value.trim();
    const m = s.match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?$/);
    if (m) {
      const h = parseInt(m[1], 10);
      const mm = parseInt(m[2], 10);
      const ss = m[3] ? parseInt(m[3], 10) : 0;
      return (h * 3600 + mm * 60 + ss) / 86400;
    }
    const n = Number(s);
    if (!isNaN(n)) return n > 1 ? n - Math.floor(n) : n;
    return null;
  }
  return null;
}

/** Format an Excel time fraction as HH:MM:SS string */
export function formatExcelTime(t: number | null): string {
  if (t === null || t === undefined || isNaN(t)) return "";
  const frac = t - Math.floor(t);
  const totalSeconds = Math.round(frac * 86400);
  const h = Math.floor(totalSeconds / 3600);
  const mm = Math.floor((totalSeconds % 3600) / 60);
  const ss = totalSeconds % 60;
  return `${String(h).padStart(2, "0")}:${String(mm).padStart(2, "0")}:${String(ss).padStart(2, "0")}`;
}

/** Format an Excel duration (fraction of day) as H:MM:SS (can exceed 24h) */
export function formatExcelDuration(t: number | null): string {
  if (t === null || t === undefined || isNaN(t) || t === 0) return "0:00:00";
  const totalSeconds = Math.round(Math.abs(t) * 86400);
  const h = Math.floor(totalSeconds / 3600);
  const mm = Math.floor((totalSeconds % 3600) / 60);
  const ss = totalSeconds % 60;
  return `${h}:${String(mm).padStart(2, "0")}:${String(ss).padStart(2, "0")}`;
}

// ---- Types ----

export interface RawDataRow {
  activityType: string; // A: عنوان دوره (normalized)
  activityTypeRaw: string; // A: original value
  terminalNo: string; // B
  areaCode: string; // C
  supportType: string; // D
  date: string; // E
  time: number | null; // F (Excel fraction)
}

export interface ReportRow {
  date: string; // A
  areaName: string; // B
  areaCode: string; // C
  supporter: string; // D
  counts: Record<string, number>; // E..I counts per activity header
  morningStart: number | null; // K
  morningEnd: number | null; // L
  afternoonStart: number | null; // M
  afternoonEnd: number | null; // N
  usefulHours: number | null; // O (Excel time fraction)
  notes: string; // P
  gapCount: number; // Q
}

export interface ProcessResult {
  reportRows: ReportRow[];
  activityHeaders: string[];
  threshold: number;
  thresholdFormatted: string;
  rawDataCount: number;
  detectedFormat: "raw-only" | "template";
  unknownAreaCodes: string[];
  warnings: string[];
  areaMap: Record<string, AreaInfo>;
}

export interface ProcessOptions {
  thresholdOverride?: number | null;
  /** Optional override for the area→(name,supporter) map. */
  areaMapOverride?: Record<string, AreaInfo> | null;
  /** Optional override for activity headers (canonical labels). */
  activityHeadersOverride?: string[] | null;
}

// ---- Format detection ----

const RAW_SHEET_CANDIDATES = ["دیتای کارکرد", "Data"];
const TEMPLATE_SHEET_CANDIDATES = ["Sheet1", "گزارش کارکرد روزانه", "Report"];
const MEDIAN_SHEET_CANDIDATES = ["تعیین میانه", "Median"];

interface DetectedFormat {
  format: "raw-only" | "template";
  dataSheet: ExcelJS.Worksheet;
  reportSheet: ExcelJS.Worksheet | null;
  medianSheet: ExcelJS.Worksheet | null;
}

function detectFormat(workbook: ExcelJS.Workbook): DetectedFormat | null {
  const findSheet = (candidates: string[]) => {
    for (const name of candidates) {
      const ws = workbook.getWorksheet(name);
      if (ws) return ws;
    }
    return null;
  };

  const dataSheet = findSheet(RAW_SHEET_CANDIDATES);
  const reportSheet = findSheet(TEMPLATE_SHEET_CANDIDATES);
  const medianSheet = findSheet(MEDIAN_SHEET_CANDIDATES);

  // Template format: has explicit "دیتای کارکرد" + "Sheet1" sheets
  if (dataSheet && reportSheet) {
    return { format: "template", dataSheet, reportSheet, medianSheet };
  }

  // Raw-only format: single sheet (or first sheet) contains the raw data.
  // The header row may be in row 1 OR row 2 (some exports add a title row
  // before the header). We scan the first few rows to find the header.
  const sheets = workbook.worksheets;
  if (sheets.length === 0) return null;

  // Try each sheet (prefer the first one that looks like raw data)
  for (const sheet of sheets) {
    const headerInfo = findHeaderRow(sheet);
    if (headerInfo) {
      // Attach the detected header row offset to the sheet for later use
      (sheet as ExcelJS.Worksheet & { _headerRow?: number })._headerRow =
        headerInfo.row;
      return {
        format: "raw-only",
        dataSheet: sheet,
        reportSheet: null,
        medianSheet,
      };
    }
  }

  return null;
}

/**
 * Scan the first ~10 rows of a sheet to find the raw-data header row.
 * Returns the row number (1-indexed) if found, else null.
 *
 * Recognized header markers (in column A or B):
 *   - "عنوان دوره" / "CourseTitle"
 *   - Or a non-empty cell in col A + non-empty in col E (date) + non-empty in
 *     col F (time) — the minimal raw-data shape.
 */
function findHeaderRow(
  sheet: ExcelJS.Worksheet
): { row: number } | null {
  const maxScan = Math.min(sheet.rowCount || 10, 10);
  for (let r = 1; r <= maxScan; r++) {
    const row = sheet.getRow(r);
    const a = normalizeCellToString(row.getCell(1).value);
    const b = normalizeCellToString(row.getCell(2).value);
    const e = normalizeCellToString(row.getCell(5).value);
    const f = normalizeCellToString(row.getCell(6).value);

    // Strong signal: header explicitly mentions "عنوان دوره" / "CourseTitle"
    if (
      a.includes("عنوان دوره") ||
      a.includes("CourseTitle") ||
      a.toLowerCase().includes("coursetitle") ||
      b.includes("TerminalNo") ||
      b.includes("شماره ترمینال") ||
      e.includes("PMpDate") ||
      e.includes("تاریخ پشتیبانی") ||
      f.includes("PMpTime") ||
      f.includes("زمان پشتیبانی")
    ) {
      return { row: r };
    }

    // Weaker signal: only check on row 1 (to avoid false positives in data)
    if (r === 1 && a && e && f) {
      return { row: r };
    }
  }
  return null;
}

// ---- Core processing ----

export async function processExcelFile(
  fileBuffer: ArrayBuffer,
  options: ProcessOptions = {}
): Promise<ProcessResult> {
  const workbook = new ExcelJS.Workbook();
  // Wrap exceljs load in try/catch to give a friendly error for corrupt or
  // non-xlsx files (e.g. old .xls renamed to .xlsx).
  try {
    await workbook.xlsx.load(fileBuffer);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    if (
      msg.includes("central directory") ||
      msg.includes("zip") ||
      msg.includes("Can't find end")
    ) {
      throw new Error(
        "فایل اکسل قابل خواندن نیست. به نظر می‌رسد فایل یا خراب است یا در فرمت قدیمی .xls (نه .xlsx) ذخیره شده. لطفاً فایل را در اکسل باز کنید و با فرمت «Excel Workbook (.xlsx)» ذخیره کنید."
      );
    }
    throw new Error(`خطا در خواندن فایل اکسل: ${msg}`);
  }

  const warnings: string[] = [];
  const detected = detectFormat(workbook);
  if (!detected) {
    throw new Error(
      "ساختار فایل قابل تشخیص نیست. لطفاً مطمئن شوید فایل شامل ستون‌های «عنوان دوره، شماره ترمینال، کد منطقه، نوع پشتیبانی، تاریخ، زمان» است."
    );
  }

  // Determine the header row offset (for raw-only format, we may have detected
  // the header on row 2 instead of row 1).
  const headerRowOffset =
    (detected.dataSheet as ExcelJS.Worksheet & { _headerRow?: number })
      ._headerRow ?? 1;

  // --- Read raw data ---
  const rawData: RawDataRow[] = [];
  detected.dataSheet.eachRow((row, rowNum) => {
    if (rowNum <= headerRowOffset) return; // skip header (and any title row above it)
    const activityType = normalizeCellToString(row.getCell(1).value);
    const terminalNo = normalizeCellToString(row.getCell(2).value);
    const areaCode = normalizeCellToString(row.getCell(3).value);
    const supportType = normalizeCellToString(row.getCell(4).value);
    const date = normalizeCellToString(row.getCell(5).value);
    const time = toExcelTime(row.getCell(6).value);

    if (
      !activityType &&
      !terminalNo &&
      !areaCode &&
      !date &&
      time === null
    ) {
      return; // skip fully-empty rows
    }

    rawData.push({
      activityType: normalizeActivityType(activityType),
      activityTypeRaw: activityType,
      terminalNo,
      areaCode,
      supportType,
      date,
      time,
    });
  });

  // --- Determine activity headers ---
  let activityHeaders: string[];
  if (options.activityHeadersOverride && options.activityHeadersOverride.length > 0) {
    activityHeaders = options.activityHeadersOverride;
  } else {
    // Collect unique normalized activity types from data
    const seen = new Set<string>();
    rawData.forEach((r) => {
      if (r.activityType) seen.add(r.activityType);
    });
    // Start with defaults, then append any extras found in data
    activityHeaders = [...DEFAULT_ACTIVITY_HEADERS];
    seen.forEach((a) => {
      if (!activityHeaders.includes(a)) activityHeaders.push(a);
    });
  }

  // --- Determine threshold ---
  let threshold = DEFAULT_THRESHOLD;
  if (detected.medianSheet) {
    const b2 = detected.medianSheet.getRow(2).getCell(2).value;
    const t = toExcelTime(b2);
    if (t !== null) threshold = t;
  }
  if (options.thresholdOverride !== null && options.thresholdOverride !== undefined) {
    threshold = options.thresholdOverride;
  }

  // --- Determine area map ---
  const areaMap: Record<string, AreaInfo> = {
    ...DEFAULT_AREA_MAP,
    ...(options.areaMapOverride || {}),
  };

  // --- Build report rows ---
  let reportRows: ReportRow[];
  let unknownAreaCodes: string[] = [];

  if (detected.format === "template" && detected.reportSheet) {
    // Read pre-defined report rows from the template's Sheet1 (row 3+)
    reportRows = [];
    detected.reportSheet.eachRow((row, rowNum) => {
      if (rowNum < 3) return;
      const date = normalizeCellToString(row.getCell(1).value);
      const areaName = normalizeCellToString(row.getCell(2).value);
      const areaCode = normalizeCellToString(row.getCell(3).value);
      const supporter = normalizeCellToString(row.getCell(4).value);
      const notes = normalizeCellToString(row.getCell(16).value);
      if (!date && !areaName && !areaCode && !supporter) return;

      const matching = rawData.filter(
        (r) => r.date === date && r.areaCode === areaCode
      );
      reportRows.push(
        buildReportRow(
          date,
          areaName || areaMap[areaCode]?.areaName || "",
          areaCode,
          supporter || areaMap[areaCode]?.supporter || "",
          matching,
          activityHeaders,
          notes,
          threshold
        )
      );
    });
  } else {
    // Raw-only format: discover (date, areaCode) combos dynamically
    const comboKeys = new Set<string>();
    const orderedCombos: { date: string; areaCode: string }[] = [];
    rawData.forEach((r) => {
      if (!r.date || !r.areaCode) return;
      const key = `${r.date}\u0001${r.areaCode}`;
      if (!comboKeys.has(key)) {
        comboKeys.add(key);
        orderedCombos.push({ date: r.date, areaCode: r.areaCode });
      }
    });

    // Sort: by date ascending, then by areaCode ascending
    orderedCombos.sort((a, b) => {
      if (a.date !== b.date) return a.date < b.date ? -1 : 1;
      return a.areaCode < b.areaCode ? -1 : 1;
    });

    reportRows = orderedCombos.map(({ date, areaCode }) => {
      const matching = rawData.filter(
        (r) => r.date === date && r.areaCode === areaCode
      );
      const info = areaMap[areaCode];
      if (!info) {
        if (!unknownAreaCodes.includes(areaCode)) {
          unknownAreaCodes.push(areaCode);
        }
      }
      return buildReportRow(
        date,
        info?.areaName || "",
        areaCode,
        info?.supporter || "",
        matching,
        activityHeaders,
        "",
        threshold
      );
    });
  }

  if (unknownAreaCodes.length > 0) {
    warnings.push(
      `کد منطقه‌های زیر در نقشه پشتیبان یافت نشدند: ${unknownAreaCodes.join("، ")}`
    );
  }

  return {
    reportRows,
    activityHeaders,
    threshold,
    thresholdFormatted: formatExcelTime(threshold),
    rawDataCount: rawData.length,
    detectedFormat: detected.format,
    unknownAreaCodes,
    warnings,
    areaMap,
  };
}

// ---- Report row builder ----

function buildReportRow(
  date: string,
  areaName: string,
  areaCode: string,
  supporter: string,
  matching: RawDataRow[],
  activityHeaders: string[],
  notes: string,
  threshold: number
): ReportRow {
  // Counts per activity header (E..I). Index 0..4 maps to columns E..I.
  const counts: Record<string, number> = {};
  activityHeaders.forEach((header, idx) => {
    const col = 5 + idx; // E=5..
    counts[`col${col}`] = matching.filter(
      (r) => r.activityType === header
    ).length;
  });

  // Morning times: time < threshold (median)
  // The morning/afternoon split uses the median threshold (default 14:00:33),
  // NOT 13:00 as in the original Excel formula. Records between 13:00 and
  // the median are classified as MORNING, matching the user's expectation.
  const morningTimes = matching
    .map((r) => r.time)
    .filter((t): t is number => t !== null && t < threshold);
  const morningStart =
    morningTimes.length > 0 ? Math.min(...morningTimes) : null;
  const morningEnd =
    morningTimes.length > 0 ? Math.max(...morningTimes) : null;

  // Afternoon times: time >= threshold (median)
  const afternoonTimes = matching
    .map((r) => r.time)
    .filter((t): t is number => t !== null && t >= threshold);
  const afternoonStart =
    afternoonTimes.length > 0 ? Math.min(...afternoonTimes) : null;
  const afternoonEnd =
    afternoonTimes.length > 0 ? Math.max(...afternoonTimes) : null;

  const morningDur =
    morningStart !== null && morningEnd !== null
      ? morningEnd - morningStart
      : 0;
  const afternoonDur =
    afternoonStart !== null && afternoonEnd !== null
      ? afternoonEnd - afternoonStart
      : 0;
  const usefulHours = morningDur + afternoonDur;

  const gapCount = countTimeGaps(matching, threshold);

  return {
    date,
    areaName,
    areaCode,
    supporter,
    counts,
    morningStart,
    morningEnd,
    afternoonStart,
    afternoonEnd,
    usefulHours: usefulHours > 0 ? usefulHours : null,
    notes,
    gapCount,
  };
}

/**
 * Replicates the VBA CountTimeGaps function:
 * - Iterates through matching rows IN DATA SHEET ORDER (not sorted by time)
 * - Counts gaps where (currentTime - prevTime) > threshold
 * - threshold is an Excel time fraction (e.g. 0.5837 = 14 hours)
 */
function countTimeGaps(rows: RawDataRow[], threshold: number): number {
  const withTime = rows.filter((r) => r.time !== null);
  if (withTime.length < 2) return 0;

  let gaps = 0;
  let prevTime = withTime[0].time as number;
  for (let i = 1; i < withTime.length; i++) {
    const t = withTime[i].time as number;
    if (t - prevTime > threshold) {
      gaps++;
    }
    prevTime = t;
  }
  return gaps;
}

// ---- Helpers ----

function normalizeActivityType(raw: string): string {
  const key = raw.trim().toLowerCase();
  return ACTIVITY_ALIASES[key] || raw.trim();
}

function normalizeCellToString(value: unknown): string {
  if (value === null || value === undefined) return "";
  if (typeof value === "string") return value.trim();
  if (typeof value === "number") return String(value);
  if (typeof value === "boolean") return value ? "TRUE" : "FALSE";
  if (value instanceof Date) {
    return value.toISOString();
  }
  if (typeof value === "object") {
    const obj = value as {
      formula?: string;
      result?: unknown;
      text?: string;
      richText?: { text: string }[];
    };
    if (obj.result !== undefined && obj.result !== null) {
      return normalizeCellToString(obj.result);
    }
    if (obj.richText && Array.isArray(obj.richText)) {
      return obj.richText.map((rt) => rt.text || "").join("").trim();
    }
    if (obj.text !== undefined) return String(obj.text).trim();
    if (obj.formula !== undefined) return "";
  }
  return String(value).trim();
}

// ---- Output generation ----

/**
 * Build a new xlsx workbook containing only the report (values only, no formulas).
 * Preserves the same layout as the original Sheet1.
 */
export async function buildReportWorkbook(
  result: ProcessResult
): Promise<ExcelJS.Buffer> {
  const wb = new ExcelJS.Workbook();
  wb.creator = "گزارش کارکرد هوشمند - ابزار وب";
  wb.created = new Date();

  const ws = wb.addWorksheet("گزارش کارکرد روزانه", {
    views: [{ rightToLeft: true }],
  });

  ws.columns = [
    { width: 14 }, // A تاریخ
    { width: 14 }, // B نام ناحیه
    { width: 12 }, // C کد منطقه
    { width: 16 }, // D پشتیبان
    { width: 10 }, // E 1404-4
    { width: 8 }, // F EM
    { width: 8 }, // G نصب
    { width: 12 }, // H EM ویژه
    { width: 12 }, // I بازاریابی
    { width: 22 }, // J کد ملی
    { width: 14 }, // K ساعت شروع صبح
    { width: 14 }, // L ساعت پایان صبح
    { width: 16 }, // M ساعت شروع بعدازظهر
    { width: 16 }, // N ساعت پایان بعدازظهر
    { width: 16 }, // O ساعت کارکرد مفید
    { width: 22 }, // P توضیحات
    { width: 14 }, // Q تعداد کار با گپ
  ];

  // Title row
  ws.mergeCells("A1:Q1");
  const titleCell = ws.getCell("A1");
  titleCell.value = "گزارش کار کرد روزانه";
  titleCell.font = {
    bold: true,
    size: 14,
    name: "Tahoma",
    color: { argb: "FFFFFFFF" },
  };
  titleCell.alignment = { horizontal: "center", vertical: "middle" };
  titleCell.fill = {
    type: "pattern",
    pattern: "solid",
    fgColor: { argb: "FF1F2937" },
  };
  ws.getRow(1).height = 28;

  // Header row (row 2)
  const headers = [
    "تاریخ",
    "نام ناحیه",
    "کد منطقه",
    "پشتیبان",
    result.activityHeaders[0] || "1404-4",
    result.activityHeaders[1] || "EM",
    result.activityHeaders[2] || "نصب",
    result.activityHeaders[3] || "EM ویژه",
    result.activityHeaders[4] || "بازاریابی",
    "کد ملی صاحب حساب بازاریابی",
    "ساعت شروع بکار صبح",
    "ساعت پایان بکار صبح",
    "ساعت شروع بکار بعداز ظهر",
    "ساعت پایان بکار بعداز ظهر",
    "ساعت کار کرد مفید",
    "توضیحات",
    "تعداد کار با گپ",
  ];
  headers.forEach((h, i) => {
    const cell = ws.getCell(2, i + 1);
    cell.value = h;
    cell.font = {
      bold: true,
      size: 11,
      name: "Tahoma",
      color: { argb: "FFFFFFFF" },
    };
    cell.alignment = {
      horizontal: "center",
      vertical: "middle",
      wrapText: true,
    };
    cell.fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FF374151" },
    };
    cell.border = thinBorder();
  });
  ws.getRow(2).height = 36;

  // Data rows
  const TIME_FMT = "hh:mm:ss";
  result.reportRows.forEach((r, idx) => {
    const rowNum = idx + 3;
    const cells: (string | number)[] = [
      r.date,
      r.areaName,
      r.areaCode,
      r.supporter,
      r.counts["col5"] ?? 0,
      r.counts["col6"] ?? 0,
      r.counts["col7"] ?? 0,
      r.counts["col8"] ?? 0,
      r.counts["col9"] ?? 0,
      "", // J: کد ملی (manual)
      r.morningStart ?? "",
      r.morningEnd ?? "",
      r.afternoonStart ?? "",
      r.afternoonEnd ?? "",
      r.usefulHours ?? "",
      r.notes || "",
      r.gapCount,
    ];
    cells.forEach((v, i) => {
      const cell = ws.getCell(rowNum, i + 1);
      cell.value = v === "" ? null : (v as string | number);
      cell.alignment = {
        horizontal: "center",
        vertical: "middle",
        wrapText: true,
      };
      cell.font = { size: 11, name: "Tahoma" };
      cell.border = thinBorder();
      if (i >= 10 && i <= 14) {
        cell.numFmt = TIME_FMT;
      }
    });
    if (idx % 2 === 1) {
      for (let c = 1; c <= 17; c++) {
        const cell = ws.getCell(rowNum, c);
        cell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FFF9FAFB" },
        };
      }
    }
  });

  ws.views = [{ rightToLeft: true, state: "frozen", ySplit: 2 }];

  // Info sheet
  const wsInfo = wb.addWorksheet("اطلاعات", {
    views: [{ rightToLeft: true }],
  });
  wsInfo.columns = [{ width: 28 }, { width: 22 }];
  const infoRows: [string, string | number][] = [
    ["قالب تشخیص داده‌شده", result.detectedFormat === "raw-only" ? "دیتای خام (تک‌شیت)" : "قالب اصلی"],
    ["آستانه گپ زمانی (Excel)", result.threshold],
    ["آستانه گپ زمانی (ساعت:دقیقه:ثانیه)", result.thresholdFormatted],
    ["تعداد رکوردهای دیتای خام", result.rawDataCount],
    ["تعداد ردیف‌های گزارش", result.reportRows.length],
    ["انواع فعالیت شناسایی‌شده", result.activityHeaders.join("، ")],
    ["تاریخ تولید گزارش", new Date().toLocaleString("fa-IR")],
  ];
  infoRows.forEach(([k, v], i) => {
    const row = wsInfo.getRow(i + 1);
    row.getCell(1).value = k;
    row.getCell(1).font = { bold: true, name: "Tahoma", size: 11 };
    row.getCell(2).value = v;
    row.getCell(2).font = { name: "Tahoma", size: 11 };
  });

  return wb.xlsx.writeBuffer();
}

function thinBorder(): ExcelJS.Borders {
  const b: ExcelJS.Border = {
    style: "thin",
    color: { argb: "FFD1D5DB" },
  };
  return { top: b, left: b, bottom: b, right: b };
}
