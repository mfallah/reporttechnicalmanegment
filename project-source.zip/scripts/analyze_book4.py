#!/usr/bin/env python3
"""Analyze the new sample input file Book4.xlsx."""
import openpyxl

FILE = "/home/z/my-project/upload/Book4.xlsx"

def main():
    wb = openpyxl.load_workbook(FILE, data_only=False)
    print("=" * 80)
    print("WORKBOOK ANALYSIS - Book4.xlsx")
    print("=" * 80)
    print(f"Sheet names: {wb.sheetnames}")
    print()

    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        print("=" * 80)
        print(f"SHEET: {sheet_name}")
        print(f"Dimensions: {ws.dimensions}")
        print(f"Max row: {ws.max_row}, Max col: {ws.max_column}")
        print(f"Right-to-left: {ws.sheet_view.rightToLeft}")
        print("-" * 80)

        # Print all cells with values
        for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 300), max_col=min(ws.max_column, 30)):
            for cell in row:
                if cell.value is not None:
                    val = str(cell.value)
                    is_formula = val.startswith("=") if isinstance(cell.value, str) else False
                    if len(val) > 250:
                        val = val[:250] + "...[TRUNCATED]"
                    print(f"  [{cell.coordinate}] = {repr(cell.value)}  {'[FORMULA]' if is_formula else ''}")
        print()

if __name__ == "__main__":
    main()
