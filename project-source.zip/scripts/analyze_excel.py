#!/usr/bin/env python3
"""Analyze the uploaded xlsm file - sheets, data, formulas, structure."""
import openpyxl
from pathlib import Path

FILE = "/home/z/my-project/upload/گزارش کارکرد هوشمند.xlsm"

def main():
    # Load with formulas (data_only=False to see formulas)
    wb = openpyxl.load_workbook(FILE, data_only=False, keep_vba=False)
    print("=" * 80)
    print("WORKBOOK ANALYSIS")
    print("=" * 80)
    print(f"Sheet names: {wb.sheetnames}")
    print()

    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        print("=" * 80)
        print(f"SHEET: {sheet_name}")
        print(f"Dimensions: {ws.dimensions}")
        print(f"Max row: {ws.max_row}, Max col: {ws.max_column}")
        print("-" * 80)

        # Print all cells with values and formulas
        for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 200), max_col=min(ws.max_column, 50)):
            for cell in row:
                if cell.value is not None:
                    val = str(cell.value)
                    is_formula = val.startswith("=") if isinstance(cell.value, str) else False
                    if len(val) > 300:
                        val = val[:300] + "...[TRUNCATED]"
                    print(f"  [{cell.coordinate}] = {val}  {'[FORMULA]' if is_formula else ''}")
        print()

    # Also try loading data_only=True to see cached values
    print("=" * 80)
    print("CACHED VALUES (data_only=True)")
    print("=" * 80)
    wb2 = openpyxl.load_workbook(FILE, data_only=True, keep_vba=False)
    for sheet_name in wb2.sheetnames:
        ws = wb2[sheet_name]
        print(f"\n--- {sheet_name} (cached values) ---")
        for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 200), max_col=min(ws.max_column, 50)):
            for cell in row:
                if cell.value is not None:
                    val = str(cell.value)
                    if len(val) > 200:
                        val = val[:200] + "...[TRUNCATED]"
                    print(f"  [{cell.coordinate}] = {val}")

if __name__ == "__main__":
    main()
