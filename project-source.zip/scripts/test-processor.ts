/**
 * Test the excel processor with both sample files.
 */
import { readFile, writeFile, mkdir } from "fs/promises";
import { existsSync } from "fs";
import {
  processExcelFile,
  buildReportWorkbook,
  formatExcelTime,
  formatExcelDuration,
  DEFAULT_THRESHOLD,
} from "../src/lib/excelProcessor";

async function testFile(label: string, path: string) {
  console.log("\n" + "=".repeat(80));
  console.log(`TEST: ${label}`);
  console.log("=".repeat(80));
  console.log("Reading:", path);

  const buf = await readFile(path);
  console.log("File size:", buf.length, "bytes");

  const result = await processExcelFile(
    buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength)
  );

  console.log("Format:", result.detectedFormat);
  console.log("Raw data rows:", result.rawDataCount);
  console.log("Report rows:", result.reportRows.length);
  console.log("Activity headers:", result.activityHeaders);
  console.log("Threshold (median):", result.threshold, "->", result.thresholdFormatted);
  console.log("Default threshold:", DEFAULT_THRESHOLD);
  console.log("Unknown area codes:", result.unknownAreaCodes);
  if (result.warnings.length) console.log("Warnings:", result.warnings);

  console.log("\n--- Report rows (first 8) ---");
  result.reportRows.slice(0, 8).forEach((r, i) => {
    console.log(
      `Row ${i + 3}: date=${r.date} area=${r.areaCode}(${r.areaName}) sup=${r.supporter} | ` +
        `counts=[${r.counts["col5"]},${r.counts["col6"]},${r.counts["col7"]},${r.counts["col8"]},${r.counts["col9"]}] ` +
        `K(صبح شروع)=${formatExcelTime(r.morningStart)} L(صبح پایان)=${formatExcelTime(r.morningEnd)} ` +
        `M(عصر شروع)=${formatExcelTime(r.afternoonStart)} N(عصر پایان)=${formatExcelTime(r.afternoonEnd)} ` +
        `O(مفید)=${formatExcelDuration(r.usefulHours)} Q(گپ)=${r.gapCount}`
    );
  });

  const outBuf = await buildReportWorkbook(result);
  const outPath = `/home/z/my-project/download/test-${label}.xlsx`;
  await writeFile(outPath, Buffer.from(outBuf));
  console.log("Wrote:", outPath, "size:", outBuf.byteLength, "bytes");
}

async function main() {
  const outDir = "/home/z/my-project/download";
  if (!existsSync(outDir)) await mkdir(outDir, { recursive: true });

  // Test 1: new raw-data-only daily file
  await testFile("book4", "/home/z/my-project/upload/Book4.xlsx");

  // Test 2: original multi-sheet template file (backward compat)
  await testFile("template", "/home/z/my-project/upload/گزارش کارکرد هوشمند.xlsm");

  console.log("\n" + "=".repeat(80));
  console.log("ALL TESTS PASSED");
  console.log("=".repeat(80));
}

main().catch((err) => {
  console.error("ERROR:", err);
  process.exit(1);
});
