#!/usr/bin/env python3
"""Analyze Book4.xlsx to understand the median/threshold issue.

The user says the morning/afternoon split is wrong. Currently the logic uses
NOON = 13:00:00 as the split (morning < 13:00, afternoon >= 13:00).

But the original Excel uses a "median threshold" (14:00:33 = 0.5837...) in
sheet "تعیین میانه" B2. Let me look at:
1. How the original Excel AGGREGATE formulas work
2. What role the median threshold actually plays
3. Whether the morning/afternoon split should use the median instead of 13:00
"""
import openpyxl
from collections import defaultdict

FILE = "/home/z/my-project/upload/Book4.xlsx"

wb = openpyxl.load_workbook(FILE, data_only=False)
ws = wb.active

# Group by (date, area_code) and sort times
data = defaultdict(list)
for row in ws.iter_rows(min_row=2, values_only=True):
    if not row[0]:
        continue
    if row[5] is None:
        continue  # skip rows without time (e.g. بازاریابی rows)
    activity = str(row[0]).strip()
    area_code = str(row[2]).strip()
    date = str(row[4]).strip()
    time = float(row[5])
    data[(date, area_code)].append((time, activity))

# Show times for each group, sorted
for (date, area), rows in sorted(data.items()):
    rows.sort(key=lambda x: x[0])
    print(f"\n=== {date} | area {area} ({len(rows)} records) ===")
    for t, act in rows:
        # Convert Excel time fraction to HH:MM:SS
        total_sec = int(round(t * 86400))
        h = total_sec // 3600
        m = (total_sec % 3600) // 60
        s = total_sec % 60
        time_str = f"{h:02d}:{m:02d}:{s:02d}"
        # Mark if before or after 13:00 (current logic)
        marker = "صبح" if t < 13/24 else "عصر"
        # Mark if before or after 14:00:33 (median threshold)
        median_marker = "<median" if t < 0.5837152777777778 else ">median"
        print(f"  {time_str}  {act:12s}  [{marker}] [{median_marker}]  t={t:.4f}")

print("\n\n=== Current logic vs Median threshold ===")
print(f"13:00:00 = {13/24:.6f}")
print(f"14:00:33 = {0.5837152777777778:.6f} (median from تعیین میانه sheet)")
print()
print("Issue: if morning/afternoon split should use the MEDIAN (14:00:33) instead of 13:00,")
print("then records between 13:00 and 14:00:33 would be classified as MORNING, not afternoon.")
